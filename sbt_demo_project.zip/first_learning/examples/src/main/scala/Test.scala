/**
 * Created by huangguowei on 15/6/5.
 */
object Test {

  def main(args: Array[String]) = {
    println("Hello World!")
  }

}
