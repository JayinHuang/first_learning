/**
 * Created by huangguowei on 15/6/5.
 */
object Main {

  def main(args: Array[String]) = {
    println("Hello World!")
  }

}
